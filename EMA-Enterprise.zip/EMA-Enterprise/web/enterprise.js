'use strict';
const labels = {resumen:'Resumen',pedidos:'Pedidos',historial:'Historial',catalogos:'Catálogos',reportes:'Reportes',asistente:'Asistente EMA',actividad:'Actividad'};
const fields = {cliente:'Cliente',vendedor:'Vendedor',producto:'Producto',sucursal:'Sucursal'};
const assets = new Map();
const sum = rows => rows.reduce((a,q)=>a + Number(q.monto || 0),0);
const textOrder = (a,b) => String(a).localeCompare(String(b),'es',{numeric:true,sensitivity:'base'});
const cleanKey = v => normalizeKey(v).toLowerCase();
const option = (v,text=v) => new Option(text,v);
const qty = n => Number(n).toLocaleString('es-GT',{maximumFractionDigits:2});
const todayISO = () => dayKey(Date.now());
function dayKey(ts) {
  if (ts == null || !Number.isFinite(Number(ts))) return '';
  const d = new Date(Number(ts));
  return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');
}
function loadAsset(src) {
  if (!assets.has(src)) assets.set(src,new Promise((resolve,reject)=>{
    const script=document.createElement('script');
    script.src=src; script.onload=resolve;
    script.onerror=()=>{assets.delete(src);reject(Error('No se pudo cargar '+src));};
    document.head.append(script);
  }));
  return assets.get(src);
}
function validCatalog(value) {
  return Object.fromEntries(Object.keys(fields).map(k=>[k,Array.isArray(value?.[k]) ? value[k].filter(x=>typeof x==='string' && x.trim()) : []]));
}
function validateBackup(s) {
  if (!Array.isArray(s?.quotes) || s.quotes.some(q=>!q || !q.numero || !Array.isArray(q.items) || !Number.isFinite(Number(q.monto)) || q.items.some(i=>!i || !Number.isFinite(Number(i.total))))) throw Error('Respaldo con pedidos inválidos.');
  if(new Set(s.quotes.map(q=>cleanText(q.numero))).size!==s.quotes.length) throw Error('El respaldo contiene números de pedido duplicados.');
  if (s.importHistory && (!Array.isArray(s.importHistory) || s.importHistory.some(e=>!e || (e.preview && (!Array.isArray(e.preview) || e.preview.some(q=>!q || !Array.isArray(q.items) || q.items.some(i=>!i))))))) throw Error('Historial de importaciones inválido.');
}
let activeReader = null;
function enterpriseImport(file) {
  if(activeReader) activeReader();
  const bar=$('readProgress');bar.hidden=false;bar.removeAttribute('value');
  return new Promise((resolve,reject)=>{
    const worker=new Worker('import-worker.js');
    const finish=(cb,value)=>{clearTimeout(timer);worker.terminate();activeReader=null;bar.hidden=true;cb(value);};
    const timer=setTimeout(()=>finish(reject,Error('El archivo excedió el tiempo de procesamiento. Dividilo en archivos más pequeños.')),120000);
    activeReader=()=>finish(reject,Error('Se seleccionó otro archivo.'));
    worker.onerror=()=>finish(reject,Error('No se pudo procesar el archivo.'));
    worker.onmessage=({data})=>{
      try {
        if(data.stage==='progress'){bar.max=data.total || 1;bar.value=data.loaded;return;}
        if(data.stage==='read'){bar.max=file.size || 1;bar.value=data.bytes;setImportStatus('Archivo leído · validando registros');return;}
        if(data.error) throw Error(data.error);
        if(data.html!==undefined){const parsed=parseHtmlTables(data.html);data.result=parseRows(file,parsed.rows,{format:'html-report',headerIndex:parsed.headerIndex});}
        finish(resolve,data.result);
      } catch(e){finish(reject,e);}
    };
    worker.postMessage(file);
  });
}
function showValidation(result) {
  const ids=new Set(state.quotes.map(q=>q.numero));
  const duplicates=result.quotes.filter(q=>ids.has(q.numero)).length;
  const issues=result.issues || [];
  $('validation').textContent=duplicates+' pedidos ya existen y se actualizarán al combinar. '+issues.length+' observaciones.';
  $('issueReport').hidden=!issues.length;
  $('issueReport').onclick=()=>downloadBlob(new Blob([issues.join('\n')],{type:'text/plain;charset=utf-8'}),'EMA-observaciones.txt');
}
function recordChange(action,detail,removed) {
  state.audit.unshift({id:crypto.randomUUID(),time:Date.now(),action,detail,removed});
  state.audit=state.audit.slice(0,120);
}
let demoMode=false;
const samples=Array.from({length:24},(_,i)=>{
  const ts=new Date(2026,Math.floor(i/4),3+(i%4)*6).getTime(), cantidad=1+(i*7)%11, precio=75+25*(i%3);
  return {id:'demo'+i,numero:'DEMO-'+String(i+1).padStart(3,'0'),fecha:dateText(dayKey(ts)),fechaTs:ts,cliente:'Cliente demo '+(1+i%7),vendedor:'Vendedor demo '+(1+i%3),sucursal:i%3===0?'Sucursal demo Sur':'Sucursal demo Norte',monto:cantidad*precio,items:[{descripcion:'Producto demo '+(1+i%4),cantidad,precio,total:cantidad*precio}]};
});
function dataset(){return demoMode?samples:state.quotes;}
function changeOptions(node, values, first) {
  const old=node.value;
  node.replaceChildren(option('',first),...Array.from(new Set(values.filter(Boolean))).sort(textOrder).map(x=>option(x)));
  if(Array.from(node.options).some(o=>o.value===old))node.value=old;
}
function scopeRows() {
  const from=$('from').value,to=$('to').value,seller=$('dashSeller').value,branch=$('dashBranch').value;
  return dataset().filter(q=>{
    const d=dayKey(q.fechaTs);
    return (!seller || q.vendedor===seller) && (!branch || q.sucursal===branch) && (!from || d && d>=from) && (!to || d && d<=to);
  });
}
function groups(rows,key) {
  const map=new Map();
  for(const q of rows) {
    const name=(key==='dia'?dayKey(q.fechaTs):key==='mes'?dayKey(q.fechaTs).slice(0,7):q[key]) || 'Sin dato';
    let entry=map.get(name);
    if(!entry){entry={name,orders:0,total:0};map.set(name,entry);}
    entry.orders++;entry.total+=q.monto;
  }
  return Array.from(map.values());
}
function monthly(rows){return groups(rows,'mes').filter(g=>g.name!=='Sin dato').sort((a,b)=>textOrder(a.name,b.name));}
function comparison(months) {
  if(months.length<2)return null;
  const last=months.at(-1), prev=months.at(-2), prior=new Date(last.name+'-15T12:00:00');
  prior.setMonth(prior.getMonth()-1);
  if(dayKey(prior.getTime()).slice(0,7)!==prev.name || prev.total===0)return null;
  return {change:(last.total-prev.total)/Math.abs(prev.total)*100,last,prev};
}
function table(container, headings, rows, empty='Sin registros para esta selección.') {
  container.replaceChildren();
  if(!rows.length){const p=document.createElement('p');p.className='empty-copy';p.textContent=empty;container.append(p);return;}
  const scroll=document.createElement('div');scroll.className='grid-scroll';
  const t=document.createElement('table');t.className='data-grid';
  const head=t.createTHead().insertRow();headings.forEach(s=>{const th=document.createElement('th');th.scope='col';th.textContent=s;head.append(th);});
  const body=t.createTBody();
  for(const row of rows){const tr=body.insertRow();row.forEach(v=>{const td=tr.insertCell();if(v instanceof Node)td.append(v);else td.textContent=v ?? '—';});}
  scroll.append(t);container.append(scroll);
}
function button(name,callback){const b=document.createElement('button');b.type='button';b.className='quiet';b.textContent=name;b.onclick=callback;return b;}
function resetScope(){for(const id of ['from','to','dashSeller','dashBranch'])$(id).value='';}
function viewOrder(q) {
  if(demoMode && samples.includes(q)){openInvoicePreview(q);return;}
  $('search').value='';$('dateFilter').value='todo';sellerFilterValue='todo';
  renderHistory();selected=Math.max(0,filtered.findIndex(v=>v.id===q.id));renderQuote();setTab('pedidos');
}
function renderSummary() {
  const rows=dataset();changeOptions($('dashSeller'),rows.map(q=>q.vendedor),'Todos');changeOptions($('dashBranch'),rows.map(q=>q.sucursal),'Todas');
  const filteredRows=scopeRows(), total=sum(filteredRows), series=monthly(filteredRows), c=comparison(series);
  $('sampleNote').hidden=!demoMode;$('demo').textContent=demoMode?'Salir de demo':'Explorar demo';
  const values=[money(total),qty(filteredRows.length),qty(new Set(filteredRows.map(q=>q.clientCode || cleanKey(q.cliente)).filter(Boolean)).size),money(filteredRows.length?total/filteredRows.length:0)];
  values.forEach((v,i)=>$('k'+i).textContent=v);
  $('ks0').textContent=c?((c.change>0?'+':'')+qty(c.change)+'% · '+c.last.name+' vs. '+c.prev.name):'Valor de los pedidos';
  drawTrend($('trendChart'),series.map(g=>[g.name,g.total]),$('chartMode').value,month=>{
    $('from').value=month+'-01';const d=new Date(month+'-15T12:00:00');$('to').value=dayKey(new Date(d.getFullYear(),d.getMonth()+1,0).getTime());renderSummary();
  });
  const key=$('rankBy').value;
  let ranked;
  if(key==='producto'){
    const products=new Map();for(const q of filteredRows)for(const i of q.items)products.set(i.descripcion,(products.get(i.descripcion)||0)+i.total);
    ranked=[...products];
  }else ranked=groups(filteredRows,key).map(g=>[g.name,g.total]);
  ranked.sort((a,b)=>b[1]-a[1]);
  drawRanking($('rankChart'),ranked,key==='sucursal'?'anillo':'barras',label=>{
    if(key==='producto' || label==='Sin dato'){showMatches(filteredRows.filter(q=>key==='producto'?q.items.some(i=>i.descripcion===label):!q[key]),label);return;}
    $(key==='vendedor'?'dashSeller':'dashBranch').value=label;renderSummary();
  });
  table($('recent'),['Pedido','Fecha','Cliente','Vendedor','Total'],[...filteredRows].sort((a,b)=>(b.fechaTs||0)-(a.fechaTs||0)).slice(0,6).map(q=>[button(q.numero,()=>viewOrder(q)),q.fecha,q.cliente,q.vendedor,money(q.monto)]),'Todavía no hay pedidos en esta selección. Importá un archivo o explorá la demo.');
}
function renderEnterprise(tab=document.body.dataset.view){
  if(!labels[tab])return;
  $('crumb').textContent=labels[tab];
  if(tab==='resumen')renderSummary();
  if(tab==='catalogos')renderCatalog();
  if(tab==='reportes')renderReport();
  if(tab==='asistente')renderAssistant();
  if(tab==='actividad')renderAudit();
}
function catalogValues(key) {
  const usage=new Map();
  for(const q of state.quotes){
    const values=key==='producto'?new Set(q.items.map(i=>i.descripcion)):[q[key]];
    for(const name of values)if(name)usage.set(name,(usage.get(name)||0)+1);
  }
  for(const name of state.catalog[key] || [])if(!usage.has(name))usage.set(name,0);
  return usage;
}
function openCatalog(key){$('entityType').value=key;$('entitySearch').value='';setTab('catalogos');}
let catalogLimit=100;
function renderCatalog(){
  const key=$('entityType').value, term=cleanKey($('entitySearch').value);
  const entries=[...catalogValues(key)].filter(([n])=>cleanKey(n).includes(term)).sort((a,b)=>textOrder(a[0],b[0]));
  table($('entities'),[fields[key],'Pedidos vinculados','Acciones'],entries.slice(0,catalogLimit).map(([name,count])=>{
    const actions=document.createElement('div');actions.className='actions';actions.append(button('Editar',()=>editEntity(name)));
    if(!count)actions.append(button('Eliminar',()=>openModal('Eliminar registro','¿Eliminar '+name+' del catálogo?',()=>{
      state.catalog[key]=(state.catalog[key]||[]).filter(n=>n!==name);recordChange('Eliminar '+fields[key],name);saveState();
    })));
    return [name,String(count),actions];
  }));
  if(entries.length>catalogLimit)$('entities').append(button('Mostrar más',()=>{catalogLimit+=100;renderCatalog();}));
}
function dialogEditor(title) {
  $('editTitle').textContent=title;$('editFields').replaceChildren();$('editError').textContent='';
  $('editor').showModal();return $('editFields');
}
function control(parent,label,value='',type='text',required=false){
  const wrap=document.createElement('label'),input=document.createElement('input');
  wrap.textContent=label;input.type=type;input.value=value;input.required=required;
  if(type==='number')input.step='any';else input.maxLength=512;
  wrap.append(input);parent.append(wrap);return input;
}
function editEntity(old=''){
  const key=$('entityType').value,box=dialogEditor((old?'Editar ':'Agregar ')+fields[key].toLowerCase());
  const input=control(box,'Nombre',old,'text',true);input.focus();
  if(old && catalogValues(key).get(old)){const note=document.createElement('p');note.textContent='Al guardar, los pedidos vinculados usarán el nuevo nombre.';box.append(note);}
  $('editForm').onsubmit=e=>{
    e.preventDefault();const name=cleanText(input.value);
    if(!name || [...catalogValues(key).keys()].some(n=>n!==old && cleanKey(n)===cleanKey(name))){$('editError').textContent='Ingresá un nombre único.';return;}
    state.catalog[key]=[...(state.catalog[key]||[]).filter(x=>x!==old),name];
    if(old){for(const q of state.quotes){if(key==='producto'){for(const i of q.items)if(i.descripcion===old)i.descripcion=name;}else if(q[key]===old)q[key]=name;}}
    recordChange((old?'Editar ':'Alta de ')+fields[key],name);$('editor').close();saveState();renderHistory();renderQuote();toast('Registro guardado.','ok');
  };
}
function editOrder(original) {
  const box=dialogEditor(original?'Editar pedido':'Crear pedido');
  const head=document.createElement('div');head.className='form-grid';box.append(head);
  const num=control(head,'Número',original?.numero,'text',true),date=control(head,'Fecha',original?dayKey(original.fechaTs):todayISO(),'date',true);
  const inputs={};
  for(const [key,label] of Object.entries({cliente:'Cliente',direccion:'Dirección',vendedor:'Vendedor',sucursal:'Sucursal'})){
    inputs[key]=control(head,label,original?.[key],'text',key==='cliente');
    if(fields[key])attachList(box,inputs[key],key);
  }
  const lines=document.createElement('div');lines.className='order-lines';box.append(lines);
  function addLine(item={}) {
    const row=document.createElement('fieldset');row.className='line-edit';lines.append(row);
    const desc=control(row,'Producto',item.descripcion,'text',true);attachList(box,desc,'producto');
    const units=control(row,'Cantidad',item.cantidad??1,'number',true),price=control(row,'Precio (Q)',item.precio??'','number',true);
    const amount=control(row,'Importe (Q)',item.total??'','number',true);
    function compute(){amount.value=(Math.round(Number(units.value)*Number(price.value)*100)/100).toString();}
    units.oninput=price.oninput=compute;row.append(button('Quitar',()=>row.remove()));
    row.getValue=()=>({codigo:'',descripcion:cleanText(desc.value),cantidad:units.valueAsNumber,precio:price.valueAsNumber,total:amount.valueAsNumber});
  }
  for(const item of original?.items || [{}])addLine(item);
  box.append(button('Agregar línea',()=>addLine()));
  num.focus();
  $('editForm').onsubmit=e=>{
    e.preventDefault();const numero=cleanText(num.value),items=[...lines.children].map(n=>n.getValue());
    if(!numero || !cleanText(inputs.cliente.value) || !items.length || items.some(i=>!i.descripcion || ![i.cantidad,i.precio,i.total].every(Number.isFinite))){$('editError').textContent='Completá el cliente y al menos una línea válida.';return;}
    if(state.quotes.some(q=>q!==original && cleanKey(q.numero)===cleanKey(numero))){$('editError').textContent='Ya existe un pedido con ese número.';return;}
    const lineTotal=items.reduce((n,i)=>n+i.total,0), originalLines=original?.items.reduce((n,i)=>n+i.total,0);
    const q={...original,id:original?.id || 'q_'+crypto.randomUUID(),numero,fecha:dateText(date.value),fechaTs:parseDate(date.value),items,monto:original && originalLines===lineTotal?original.monto:Math.round(lineTotal*100)/100,createdAt:original?.createdAt || Date.now()};
    for(const key of Object.keys(inputs))q[key]=cleanText(inputs[key].value);
    if(original && q.cliente!==original.cliente)q.clientCode='';
    if(original && q.vendedor!==original.vendedor)q.vendedorCode='';
    if(original)state.quotes[state.quotes.indexOf(original)]=q;else state.quotes.push(q);
    recordChange(original?'Editar pedido':'Crear pedido',q.numero);$('editor').close();saveState();viewOrder(q);toast('Pedido guardado.','ok');
  };
}
function attachList(box,input,key) {
  const id='list-'+key;
  if(!$(id)){const list=document.createElement('datalist');list.id=id;for(const n of catalogValues(key).keys())list.append(option(n));box.append(list);}
  input.setAttribute('list',id);
}
function reportRows(){
  const key=$('reportGroup').value;
  return groups(scopeRows(),key).sort((a,b)=>key==='dia'||key==='mes'?textOrder(a.name,b.name):b.total-a.total);
}
function renderReport(){
  const list=reportRows(),rows=scopeRows();
  table($('report'),[$('reportGroup').selectedOptions[0].text,'Pedidos','Ventas','Promedio'],list.map(g=>[g.name,g.orders,money(g.total),money(g.total/g.orders)]));
  const p=document.createElement('p');p.className='report-total';p.textContent=(demoMode?'Demostración · ':'')+rows.length+' pedidos · Total '+money(sum(rows));$('report').append(p);
  $('reportXls').disabled=$('reportPdf').disabled=!rows.length;
}
function reportTitle(){
  return (demoMode?'DEMOSTRACIÓN · ':'')+'Ventas por '+$('reportGroup').selectedOptions[0].text.toLowerCase();
}
function filterText(){
  return [($('from').value || 'Inicio')+' / '+($('to').value || 'Último registro'),$('dashSeller').value || 'Todos los vendedores',$('dashBranch').value || 'Todas las sucursales'].join(' · ');
}
async function exportReport(format) {
  const groups=reportRows(),rows=scopeRows();if(!rows.length)return;
  const title=reportTitle(), when=new Date().toLocaleDateString('es-GT');
  if(format==='xlsx'){
    await loadAsset('lib/xlsx.full.min.js');const wb=XLSX.utils.book_new();
    const sheet=XLSX.utils.aoa_to_sheet([['EMA Enterprise',title],[filterText()],[when],[],['Grupo','Pedidos','Ventas (Q)','Promedio (Q)'],...groups.map(g=>[g.name,g.orders,g.total,g.total/g.orders]),['TOTAL',rows.length,sum(rows)]]);
    sheet['!cols']=[{wch:40},{wch:18},{wch:22},{wch:22}];XLSX.utils.book_append_sheet(wb,sheet,'Resumen');
    XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([['Pedido','Fecha','Cliente','Vendedor','Sucursal','Ventas (Q)'],...rows.map(q=>[q.numero,q.fecha,q.cliente,q.vendedor,q.sucursal||'',q.monto])]),'Pedidos');
    downloadBlob(new Blob([XLSX.write(wb,{bookType:'xlsx',type:'array'})],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}),'EMA-reporte.xlsx');return;
  }
  await loadAsset('lib/jspdf.umd.min.js');const doc=new window.jspdf.jsPDF();let y;
  function header(){
    doc.setFillColor(17,57,47);doc.rect(0,0,210,25,'F');doc.setTextColor(255);doc.setFontSize(16);doc.text('EMA Enterprise',14,16);
    doc.setTextColor(25);doc.setFontSize(13);doc.text(title,14,36);doc.setFontSize(9);
    const lines=doc.splitTextToSize(filterText(),175);doc.text(lines,14,44);y=50+lines.length*4;
    doc.text('Generado '+when,14,y);y+=9;doc.text('Grupo',14,y);doc.text('Pedidos',140,y,{align:'right'});doc.text('Ventas',196,y,{align:'right'});y+=7;
  }
  header();
  for(const g of [...groups,{name:'TOTAL',orders:rows.length,total:sum(rows)}]){
    const lines=doc.splitTextToSize(g.name,100);if(y+lines.length*4>272){doc.addPage();header();}
    doc.text(lines,14,y);doc.text(String(g.orders),140,y,{align:'right'});doc.text(money(g.total),196,y,{align:'right'});y+=Math.max(7,lines.length*4+3);
  }
  for(let i=1;i<=doc.getNumberOfPages();i++){doc.setPage(i);doc.text(i+' / '+doc.getNumberOfPages(),196,287,{align:'right'});}
  downloadBlob(doc.output('blob'),'EMA-reporte.pdf');
}
function renderAssistant() {
  const rows=scopeRows(), months=monthly(rows),c=comparison(months),question=$('question').value,out=$('answer');
  let answers=[];
  if(question==='indicadores') answers=['Ventas totales suma los importes de los pedidos en quetzales.','Clientes activos cuenta los clientes distintos que registraron pedidos en la selección.','Ticket promedio divide las ventas entre la cantidad de pedidos.'];
  else if(!rows.length)answers=['La selección no contiene pedidos. Importá registros o ajustá los filtros para calcular resultados.'];
  else if(question==='comparar')answers=[c?c.last.name+' registró '+money(c.last.total)+' frente a '+money(c.prev.total)+' en '+c.prev.name+'. Variación: '+qty(c.change)+' %.':'La comparación requiere dos meses consecutivos con datos y una base distinta de cero.'];
  else if(question==='proyeccion'){
    const current=todayISO().slice(0,7), completed=months.filter(m=>m.name<current).slice(-3);
    const successive=completed.length===3 && completed.every((m,i)=>{const d=new Date(completed[0].name+'-15T12:00:00');d.setMonth(d.getMonth()+i);return dayKey(d.getTime()).slice(0,7)===m.name;});
    answers=[successive?'Estimación para el mes siguiente al '+completed[2].name+': '+money(completed.reduce((a,m)=>a+m.total,0)/3)+'. Promedio simple de tres meses consecutivos del filtro, sin ajuste estacional.':'Se necesitan tres meses consecutivos anteriores al mes actual para calcular una estimación.'];
  }else if(question==='calidad'){
    const amounts=rows.map(q=>q.monto).sort((a,b)=>a-b), q1=amounts[Math.floor((amounts.length-1)*.25)],q3=amounts[Math.floor((amounts.length-1)*.75)];
    const incomplete=rows.filter(q=>!q.cliente || !q.vendedor || !q.fechaTs), unbalanced=rows.filter(q=>Math.abs(q.monto-q.items.reduce((a,i)=>a+i.total,0))>.01);
    answers=['Datos incompletos de cliente, vendedor o fecha: '+incomplete.length+'.','Pedidos cuyo importe difiere de la suma de líneas: '+unbalanced.length+'.',rows.length>=8?'Importes fuera de los límites de Tukey (1,5 veces el rango intercuartílico): '+rows.filter(q=>q.monto<q1-1.5*(q3-q1)||q.monto>q3+1.5*(q3-q1)).length+'. Revisá estos pedidos en el historial.':'Se necesitan ocho pedidos para la alerta estadística de importes atípicos.'];
  }else{
    const leader=groups(rows.filter(q=>q.vendedor),'vendedor').sort((a,b)=>b.total-a.total)[0];
    answers=[rows.length+' pedidos suman '+money(sum(rows))+'. El promedio es '+money(sum(rows)/rows.length)+'.',leader?'El mayor importe por vendedor corresponde a '+leader.name+' con '+money(leader.total)+'.':'Falta asignar vendedores para comparar su rendimiento.',c?'La variación entre '+c.prev.name+' y '+c.last.name+' fue de '+qty(c.change)+' %.':'Sin dos meses consecutivos comparables.'];
  }
  out.replaceChildren();if(demoMode)answers.unshift('Análisis de datos de demostración.');
  for(const a of answers){const p=document.createElement('p');p.textContent=a;out.append(p);}
}
function renderAudit(){
  table($('auditLog'),['Fecha y hora','Operación','Detalle','Recuperación'],state.audit.filter(e=>e && typeof e==='object').map(e=>{
    const recover=e.removed && !state.quotes.some(q=>q.numero===e.removed.numero);
    return [new Date(e.time).toLocaleString('es-GT'),e.action,e.detail,recover?button('Recuperar',()=>{
      state.quotes.push(normalizeQuote(e.removed));delete e.removed;recordChange('Recuperar pedido',e.detail);saveState();renderHistory();renderQuote();
    }):'—'];
  }));
}
function searchData(term) {
  const keys=cleanKey(term).split(' ').filter(Boolean);
  return state.quotes.filter(q=>{const text=cleanKey([q.numero,q.cliente,q.vendedor,q.sucursal,q.direccion,...q.items.map(i=>i.descripcion)].join(' '));return keys.every(k=>text.includes(k));});
}
function showMatches(rows,term) {
  if(!$('finder').open)$('finder').showModal();
  $('findText').value=term;renderMatches(rows);
}
function renderMatches(rows) {
  const box=$('found');box.replaceChildren();
  const p=document.createElement('p');p.textContent=rows.length+' pedidos encontrados'+(rows.length>50?' · primeros 50':'');box.append(p);
  for(const q of rows.slice(0,50))box.append(button(q.numero+' · '+q.cliente+' · '+money(q.monto),()=>{$('finder').close();viewOrder(q);}));
}
document.addEventListener('DOMContentLoaded',()=>{
  try{document.documentElement.dataset.theme=localStorage.getItem('ema-theme') || (matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');}catch(_){}
  $('theme').onclick=()=>{const root=document.documentElement;root.dataset.theme=root.dataset.theme==='dark'?'light':'dark';try{localStorage.setItem('ema-theme',root.dataset.theme);}catch(_){}};
  $('menu').onclick=()=>document.body.classList.toggle(matchMedia('(max-width: 760px)').matches?'menu-open':'rail-small');
  $('scrim').onclick=()=>document.body.classList.remove('menu-open');
  document.querySelector('.wordmark').onclick=e=>{e.preventDefault();setTab('resumen');};
  for(const id of ['from','to','dashSeller','dashBranch','chartMode','rankBy'])$(id).onchange=()=>{
    if($('from').value && $('to').value && $('from').value>$('to').value){toast('El inicio debe preceder al final del período.','err');$(id).value='';}renderSummary();
  };
  $('demo').onclick=()=>{demoMode=!demoMode;resetScope();renderSummary();};
  $('resetDash').onclick=()=>{resetScope();renderSummary();};
  $('seeOrders').onclick=()=>demoMode?showMatches(scopeRows(),'Demostración'):setTab('historial');
  $('newOrder').onclick=()=>editOrder();
  $('newEntity').onclick=()=>editEntity();
  $('entityType').onchange=$('entitySearch').oninput=()=>{catalogLimit=100;renderCatalog();};
  $('reportGroup').onchange=renderReport;$('question').onchange=renderAssistant;
  $('reportFilters').onclick=()=>setTab('resumen');
  $('reportXls').onclick=()=>actionSafe(()=>exportReport('xlsx'),'Exportación');
  $('reportPdf').onclick=()=>actionSafe(()=>exportReport('pdf'),'Exportación');
  $('globalSearch').onclick=()=>{showMatches(searchData(''),'');$('findText').focus();};
  $('findText').oninput=()=>renderMatches(searchData($('findText').value));
  document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>b.closest('dialog').close());
  document.addEventListener('keydown',e=>{if(e.key==='/' && !e.ctrlKey && !e.metaKey && !e.target.matches('input,textarea,select') && !document.querySelector('dialog[open]')){e.preventDefault();$('globalSearch').click();}});
  document.addEventListener('ema-change',()=>renderEnterprise());
  if('serviceWorker' in navigator && location.protocol!=='file:' && !window.AndroidBridge){
    navigator.serviceWorker.register('./sw.js').then(reg=>{
      const offer=()=>{if(!reg.waiting || !navigator.serviceWorker.controller || $('updateShell'))return;
        const b=button('Actualizar EMA',()=>{navigator.serviceWorker.addEventListener('controllerchange',()=>location.reload(),{once:true});reg.waiting.postMessage({type:'SKIP_WAITING'});});
        b.id='updateShell';document.querySelector('.command').append(b);
      };
      offer();reg.addEventListener('updatefound',()=>reg.installing?.addEventListener('statechange',offer));
    }).catch(()=>toast('Modo sin conexión no disponible en este navegador.'));
  }
});

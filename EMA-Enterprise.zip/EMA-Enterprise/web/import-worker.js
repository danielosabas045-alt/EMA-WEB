'use strict';
importScripts('parser.js');
self.onmessage = async ({data: file}) => {
  try {
    const buffer = await new Promise((resolve,reject) => {
      const reader = new FileReader();
      reader.onprogress = event => postMessage({stage:'progress', loaded:event.loaded, total:file.size});
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsArrayBuffer(file);
    });
    postMessage({stage:'read', bytes:buffer.byteLength});
    let result;
    if (/\.json$/i.test(file.name)) {
      const json = JSON.parse(new TextDecoder().decode(buffer));
      const records = Array.isArray(json) ? json : json.quotes || json.state?.quotes;
      if (!Array.isArray(records) || !records.length) throw Error('Se esperaba una lista de pedidos o filas.');
      if (records[0]?.numero && Array.isArray(records[0].items)) {
        const seen = new Set();
        const quotes = records.map((q,i) => {
          if (!q || !cleanText(q.numero) || !cleanText(q.cliente) || !q.items?.length) throw Error('Pedido incompleto en registro ' + (i+1));
          const numero = cleanText(q.numero);
          if (seen.has(numero)) throw Error('Número duplicado dentro del JSON: '+numero);
          seen.add(numero);
          const items = q.items.map(item => {
            const cantidad=Number(item.cantidad), precio=Number(item.precio), total=Number(item.total ?? cantidad*precio);
            if (!cleanText(item.descripcion) || ![cantidad,precio,total].every(Number.isFinite)) throw Error('Línea inválida en '+numero);
            return {descripcion:cleanText(item.descripcion),cantidad,precio,total,codigo:''};
          });
          const monto = Number(q.monto ?? items.reduce((a,b)=>a+b.total,0));
          if (!Number.isFinite(monto)) throw Error('Importe inválido en '+numero);
          return {id:'q_'+numero, numero, cliente:cleanText(q.cliente),clientCode:cleanText(q.clientCode),direccion:cleanText(q.direccion),vendedor:cleanText(q.vendedor),vendedorCode:cleanText(q.vendedorCode),sucursal:cleanText(q.sucursal),fecha:dateText(q.fecha),fechaTs:parseDate(q.fecha),items,monto,archivo:file.name,source:'json'};
        });
        result={quotes,reportTotal:0,issues:[]};
      } else {
        const header=Object.keys(records[0] || {});
        result=parseRows(file,[header,...records.map(r=>header.map(k=>r[k] ?? ''))],{headerIndex:0,format:'json'});
      }
    } else if (/\.html?$/i.test(file.name) || looksLikeHtml(buffer)) {
      let html=decodeText(buffer,'utf-8'); if(html.includes('�')) html=decodeText(buffer);
      // The main thread reads text from a detached, inert template (no scripts or subrequests).
      postMessage({html}); return;
    } else {
      importScripts('lib/xlsx.full.min.js');
      const csv=/\.csv$/i.test(file.name);
      const parsed=csv?parseCsv(buffer):parseExcel(buffer);
      result=parseRows(file,parsed.rows,{headerIndex:parsed.headerIndex,format:csv?'csv':'excel'});
    }
    postMessage({result});
  } catch(e) { postMessage({error:e.message || 'Archivo inválido.'}); }
};
